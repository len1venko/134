const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3000;

let latestData = {
  temperature: 'N/A',
  humidity: 'N/A',
  pressure: 'N/A',
  altitude: 'N/A',
  gas: 'N/A',
  timestamp: ''
};

app.use(bodyParser.json());
app.use(express.static('public'));

app.post('/update', (req, res) => {
  latestData = {
    ...req.body,
    timestamp: new Date().toLocaleString()
  };
  console.log('Получены данные:', latestData);
  res.sendStatus(200);
});

app.get('/data', (req, res) => {
  res.json(latestData);
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});
